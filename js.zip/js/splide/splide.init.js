
    document.addEventListener('DOMContentLoaded', function () {
        new Splide('.splide').mount();
    }); 
